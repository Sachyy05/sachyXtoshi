let sxt = 0;
let baseRate = 0.1;
let referralCount = 0;
let currentRate = baseRate;
let remainingTime = 21600;
let countdown;

function updateMiningSpeed() {
  currentRate = baseRate + (referralCount * baseRate * 0.25);
  document.getElementById("speedDisplay").innerText = currentRate.toFixed(4) + " SXT/hr";
}

function startMining() {
  document.getElementById("mineButton").disabled = true;
  sxt += currentRate * 6;
  document.getElementById("sxtCount").innerText = sxt.toFixed(2);
  remainingTime = 21600;
  countdown = setInterval(updateCountdown, 1000);
}

function updateCountdown() {
  if (remainingTime <= 0) {
    clearInterval(countdown);
    document.getElementById("mineButton").disabled = false;
    document.getElementById("timerText").innerText = "00:00:00";
    return;
  }

  remainingTime--;

  const h = Math.floor(remainingTime / 3600);
  const m = Math.floor((remainingTime % 3600) / 60);
  const s = remainingTime % 60;
  document.getElementById("timerText").innerText =
    String(h).padStart(2, '0') + ":" +
    String(m).padStart(2, '0') + ":" +
    String(s).padStart(2, '0');
}

function register() {
  const name = document.getElementById("regName").value.trim();
  const email = document.getElementById("regEmail").value.trim();
  const mobile = document.getElementById("regMobile").value.trim();
  const password = document.getElementById("regPassword").value;

  if (!name || !email || !mobile || !password) {
    alert("Please fill all fields.");
    return;
  }

  const user = { name, email, mobile, password };
  localStorage.setItem("sxtUser", JSON.stringify(user));
  alert("Registration successful! Please login.");
  showLogin();
}

function login() {
  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value;
  const savedUser = JSON.parse(localStorage.getItem("sxtUser"));

  if (!savedUser || savedUser.email !== email || savedUser.password !== password) {
    alert("Invalid email or password.");
    return;
  }

  alert("Login successful!");
  showDashboard();
}

function showRegister() {
  document.getElementById("loginBox").style.display = "none";
  document.getElementById("registerBox").style.display = "block";
  document.getElementById("dashboardSection").style.display = "none";
}

function showLogin() {
  document.getElementById("registerBox").style.display = "none";
  document.getElementById("loginBox").style.display = "block";
  document.getElementById("dashboardSection").style.display = "none";
}

function showDashboard() {
  document.getElementById("registerBox").style.display = "none";
  document.getElementById("loginBox").style.display = "none";
  document.getElementById("dashboardSection").style.display = "block";
  document.getElementById("sxtCount").innerText = sxt.toFixed(2);
  document.getElementById("timerText").innerText = "06:00:00";
  updateMiningSpeed();
}